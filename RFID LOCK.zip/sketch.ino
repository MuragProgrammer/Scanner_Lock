#include <WiFi.h>
#include <PubSubClient.h>
#include <SPI.h>
#include <MFRC522.h>
#include <ESP32Servo.h>

// ================= WIFI =================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ================= MQTT =================
const char* mqtt_server = "broker.emqx.io";

WiFiClient espClient;
PubSubClient client(espClient);

// ================= PINS =================
#define SS_PIN 5
#define RST_PIN 4

#define RELAY_PIN 26
#define SERVO_PIN 27
#define BUZZER_PIN 25

MFRC522 rfid(SS_PIN, RST_PIN);
Servo lockServo;

// ================= RFID =================
String allowedUID = "11 22 33 44";

// ================= STATE CONTROL =================
bool isLocked = true;
unsigned long lastScanTime = 0;
const unsigned long scanCooldown = 10000; // 10 seconds

// ================= WIFI =================
void setup_wifi() {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

// ================= MQTT STATUS =================
void publishStatus(const char* status) {
  client.publish("lock/door1/status", status);
}

// ================= BUZZER =================
void beepLong() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(800);
  digitalWrite(BUZZER_PIN, LOW);
}

void beepWrong() {
  for (int i = 0; i < 2; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(150);
    digitalWrite(BUZZER_PIN, LOW);
    delay(150);
  }
}

// ================= LOCK CONTROL =================
void unlockDoor() {
  Serial.println("UNLOCKING...");
  publishStatus("UNLOCKING");

  digitalWrite(RELAY_PIN, HIGH);
  lockServo.write(90);

  delay(1000); // simulate movement time

  isLocked = false;
  publishStatus("UNLOCKED");

  beepLong();
}

void lockDoor() {
  Serial.println("LOCKING...");
  publishStatus("LOCKING");

  digitalWrite(RELAY_PIN, LOW);
  lockServo.write(0);

  delay(1000);

  isLocked = true;
  publishStatus("LOCKED");
}

// ================= MQTT CALLBACK =================
void callback(char* topic, byte* payload, unsigned int length) {
  String msg = "";

  for (int i = 0; i < length; i++) {
    msg += (char)payload[i];
  }

  if (msg == "UNLOCK") unlockDoor();
  if (msg == "LOCK") lockDoor();
}

// ================= MQTT RECONNECT =================
void reconnect() {
  while (!client.connected()) {
    if (client.connect("ESP32_LOCK")) {
      client.subscribe("lock/door1/control");
      publishStatus(isLocked ? "LOCKED" : "UNLOCKED");
    } else {
      delay(2000);
    }
  }
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  lockServo.attach(SERVO_PIN);
  lockServo.write(0);

  SPI.begin();
  rfid.PCD_Init();

  setup_wifi();

  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);

  Serial.println("System Ready");
}

// ================= LOOP =================
void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  // ===== RFID COOLDOWN CHECK =====
  if (millis() - lastScanTime < scanCooldown) return;

  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;

  lastScanTime = millis(); // lock scan time

  String uid = "";

  for (byte i = 0; i < rfid.uid.size; i++) {
    uid += String(rfid.uid.uidByte[i], HEX);
    if (i < rfid.uid.size - 1) uid += " ";
  }

  uid.toUpperCase();
  uid.trim();

  Serial.println("RFID: " + uid);

  client.publish("lock/door1/rfid", uid.c_str());

  // ================= LOGIC =================
  if (uid == allowedUID) {

    if (isLocked) {
      unlockDoor();
    } else {
      lockDoor();
    }

  } else {
    Serial.println("DENIED");
    beepWrong();
    publishStatus("DENIED");
  }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}